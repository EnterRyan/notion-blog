export default function StatePage() {
  return <div>StatePage</div>;
} 